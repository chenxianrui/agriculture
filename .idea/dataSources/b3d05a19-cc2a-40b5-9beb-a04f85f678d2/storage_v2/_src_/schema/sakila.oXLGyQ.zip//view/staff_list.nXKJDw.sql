CREATE VIEW staff_list AS
  SELECT
    `s`.`staff_id`                                 AS `ID`,
    concat(`s`.`first_name`, ' ', `s`.`last_name`) AS `name`,
    `a`.`address`                                  AS `address`,
    `a`.`postal_code`                              AS `zip code`,
    `a`.`phone`                                    AS `phone`,
    `sakila`.`city`.`city`                         AS `city`,
    `sakila`.`country`.`country`                   AS `country`,
    `s`.`store_id`                                 AS `SID`
  FROM (((`sakila`.`staff` `s`
    JOIN `sakila`.`address` `a` ON ((`s`.`address_id` = `a`.`address_id`))) JOIN `sakila`.`city`
      ON ((`a`.`city_id` = `sakila`.`city`.`city_id`))) JOIN `sakila`.`country`
      ON ((`sakila`.`city`.`country_id` = `sakila`.`country`.`country_id`)));

