CREATE VIEW `x$schema_flattened_keys` AS
  SELECT
    `STATISTICS`.`TABLE_SCHEMA`                                                                     AS `TABLE_SCHEMA`,
    `STATISTICS`.`TABLE_NAME`                                                                       AS `TABLE_NAME`,
    `STATISTICS`.`INDEX_NAME`                                                                       AS `INDEX_NAME`,
    max(`STATISTICS`.`NON_UNIQUE`)                                                                  AS `non_unique`,
    max(if((`STATISTICS`.`SUB_PART` IS NULL), 0, 1))                                                AS `subpart_exists`,
    group_concat(`STATISTICS`.`COLUMN_NAME` ORDER BY `STATISTICS`.`SEQ_IN_INDEX` ASC SEPARATOR ',') AS `index_columns`
  FROM `information_schema`.`STATISTICS`
  WHERE ((`STATISTICS`.`INDEX_TYPE` = 'BTREE') AND
         (`STATISTICS`.`TABLE_SCHEMA` NOT IN ('mysql', 'sys', 'INFORMATION_SCHEMA', 'PERFORMANCE_SCHEMA')))
  GROUP BY `STATISTICS`.`TABLE_SCHEMA`, `STATISTICS`.`TABLE_NAME`, `STATISTICS`.`INDEX_NAME`;

